import threading
import logging
from typing import Any, Tuple

def execute_with_timeout(func, timeout: float, operation_name: str, log_prefix: str) -> Tuple[bool, Any]:
    """执行函数并设置超时"""
    result = [None]
    error = [None]
    completed = threading.Event()

    def worker():
        try:
            result[0] = func()
            completed.set()
        except Exception as e:
            error[0] = e
            completed.set()

    thread = threading.Thread(target=worker)
    thread.daemon = True
    thread.start()
    completed.wait(timeout)
    if not completed.is_set():
        logging.warning(f"{log_prefix}超时（{timeout}秒）")
        return False, None
    if error[0] is not None:
        logging.error(f"{log_prefix}失败: {error[0]}")
        return False, None
    return True, result[0]