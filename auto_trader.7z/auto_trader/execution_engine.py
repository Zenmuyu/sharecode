from typing import Any, Dict
import time

class ExecutionEngine:
    """统一下单接口抽象"""

    def __init__(self, main_window: Any):
        self.main = main_window

    def place_order(self, code: str, action: str, quantity: int, price: float, trade_type: str) -> Dict:
        """下单接口，返回统一格式 {success: bool, order_id: str, error: str}"""
        raise NotImplementedError()

class SimExecutionEngine(ExecutionEngine):
    """模拟执行引擎，直接返回模拟成交结果"""

    def place_order(self, code: str, action: str, quantity: int, price: float, trade_type: str) -> Dict:
        order_id = f"SIM_{int(time.time() * 1000)}"
        if hasattr(self.main, "logger"):
            self.main.logger.log(f"[模拟下单] {action} {code} 数量:{quantity} 价格:{price} 订单:{order_id}", "INFO")
        return {"success": True, "order_id": order_id, "error": ""}

class RealExecutionEngine(ExecutionEngine):
    """真实执行引擎，调用 MyQuantClient.place_order"""

    def place_order(self, code: str, action: str, quantity: int, price: float, trade_type: str) -> Dict:
        if not hasattr(self.main, "myquant_client") or not self.main.myquant_client.is_connected():
            if hasattr(self.main, "logger"):
                self.main.logger.log("MyQuant 客户端未连接", "ERROR")
            return {"success": False, "order_id": "", "error": "MyQuant 客户端未连接"}
        try:
            order_id = self.main.myquant_client.order_volume(
                symbol=code,
                volume=quantity,
                side=self.main.myquant_client.OrderSide_Buy if action == "买入" else self.main.myquant_client.OrderSide_Sell,
                order_type=self.main.myquant_client.OrderType_Limit if trade_type == "LIMIT" else self.main.myquant_client.OrderType_Market,
                price=price if trade_type == "LIMIT" else 0.0
            )
            if hasattr(self.main, "logger"):
                self.main.logger.log(f"[真实下单] {action} {code} 数量:{quantity} 价格:{price} 订单:{order_id}", "INFO")
            return {"success": True, "order_id": order_id, "error": ""}
        except Exception as e:
            if hasattr(self.main, "logger"):
                self.main.logger.log(f"[执行引擎] 下单异常: {e}", "ERROR")
            return {"success": False, "order_id": "", "error": str(e)}