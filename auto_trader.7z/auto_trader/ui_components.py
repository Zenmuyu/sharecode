import pandas as pd
import mplfinance as mpf
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit, QComboBox
from PyQt5.QtCore import Qt
import logging

class ChartWidget(QWidget):
    """K线图组件，支持技术指标"""

    def __init__(self):
        super().__init__()
        self.figure = mpf.Figure()
        self.canvas = FigureCanvas(self.figure)
        layout = QVBoxLayout(self)
        layout.addWidget(self.canvas)
        self.current_symbol = None

    def plot_data(self, df: pd.DataFrame, indicators: list = None) -> None:
        """绘制K线图，带可选技术指标"""
        try:
            if df.empty:
                logging.warning("图表数据为空")
                return
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            add_plots = []
            if indicators:
                if "MA5" in indicators:
                    df["MA5"] = df["close"].rolling(window=5).mean()
                    add_plots.append(mpf.make_addplot(df["MA5"], color="blue", label="MA5"))
                if "MA10" in indicators:
                    df["MA10"] = df["close"].rolling(window=10).mean()
                    add_plots.append(mpf.make_addplot(df["MA10"], color="orange", label="MA10"))
                if "MACD" in indicators:
                    df["ema12"] = df["close"].ewm(span=12, adjust=False).mean()
                    df["ema26"] = df["close"].ewm(span=26, adjust=False).mean()
                    df["macd"] = df["ema12"] - df["ema26"]
                    df["signal"] = df["macd"].ewm(span=9, adjust=False).mean()
                    df["hist"] = df["macd"] - df["signal"]
                    add_plots.append(mpf.make_addplot(df[["macd", "signal"]], panel=1, color=["red", "green"]))
                    add_plots.append(mpf.make_addplot(df["hist"], type="bar", panel=1))
            mpf.plot(df, type="candle", ax=ax, addplot=add_plots, title=self.current_symbol)
            self.canvas.draw()
        except Exception as e:
            logging.error(f"绘制图表失败: {e}")

class TradePanel(QWidget):
    """交易面板"""

    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        self.code_input = QLineEdit()
        self.code_input.setPlaceholderText("请输入股票代码")
        layout.addWidget(self.code_input)

        self.quantity_input = QLineEdit()
        self.quantity_input.setPlaceholderText("请输入数量")
        layout.addWidget(self.quantity_input)

        self.price_input = QLineEdit()
        self.price_input.setPlaceholderText("请输入价格")
        layout.addWidget(self.price_input)

        self.action_combo = QComboBox()
        self.action_combo.addItems(["买入", "卖出"])
        layout.addWidget(self.action_combo)

        self.trade_type_combo = QComboBox()
        self.trade_type_combo.addItems(["限价", "市价"])
        layout.addWidget(self.trade_type_combo)

        trade_button = QPushButton("下单")
        trade_button.clicked.connect(self.place_order)
        layout.addWidget(trade_button)

    def place_order(self):
        """执行下单"""
        try:
            code = self.code_input.text().strip()
            quantity = int(self.quantity_input.text().strip())
            price = float(self.price_input.text().strip()) if self.trade_type_combo.currentText() == "限价" else 0.0
            action = self.action_combo.currentText()
            trade_type = "LIMIT" if self.trade_type_combo.currentText() == "限价" else "MARKET"
            result = self.main_window.execution_engine.place_order(code, action, quantity, price, trade_type)
            if result["success"]:
                self.main_window.logger.log(f"下单成功: {result['order_id']}", "SUCCESS")
            else:
                self.main_window.logger.log(f"下单失败: {result.get('error', '未知错误')}", "ERROR")
        except Exception as e:
            self.main_window.logger.log(f"下单异常: {e}", "ERROR")