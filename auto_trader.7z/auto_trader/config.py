import json
import logging
import os
from typing import Any

class Config:
    """系统配置类，管理 config.json 文件的加载、保存和访问"""

    def __init__(self):
        self.config_file = "config.json"
        self.data = self.load_config()

    def load_config(self) -> dict:
        """加载配置文件，若不存在则返回默认配置"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logging.error(f"加载配置失败: {e}")
        return {
            "myquant": {"token": "", "account_id": ""},
            "trading": {"simulation_mode": False, "auto_trading_enabled": False},
            "account": {
                "initial_balance": 100000.0,
                "available_cash": 100000.0,
                "total_assets": 100000.0,
                "market_value": 0.0,
                "daily_pnl": 0.0,
                "save_account_info": True,
            },
            "display": {"default_period": "15m", "chart_indicators": ["MA5", "MA10", "MACD"]},
        }

    def save_config(self) -> bool:
        """保存配置文件，移除 trade_history 字段"""
        try:
            config_data = self.data.copy()
            if "trade_history" in config_data:
                del config_data["trade_history"]
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logging.error(f"保存配置失败: {e}")
            return False

    def get(self, key: str, default=None) -> Any:
        """获取配置值，支持嵌套键（如 myquant.token）"""
        keys = key.split(".")
        value = self.data
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value

    def set(self, key: str, value: Any) -> None:
        """设置配置值"""
        keys = key.split(".")
        data = self.data
        for k in keys[:-1]:
            if k not in data:
                data[k] = {}
            data = data[k]
        data[keys[-1]] = value