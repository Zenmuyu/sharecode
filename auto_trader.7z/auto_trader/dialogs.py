from PyQt5.QtWidgets import QDialog, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, QMessageBox, QComboBox, QLineEdit
from PyQt5.QtCore import Qt
from .myquant_client import MyQuantClient
from .config import Config
from datetime import datetime, timedelta
import pandas as pd
import logging

class OrdersDialog(QDialog):
    """订单查询对话框"""

    def __init__(self, myquant_client: MyQuantClient, config: Config, parent=None):
        super().__init__(parent)
        self.myquant_client = myquant_client
        self.config = config
        self.setWindowTitle("订单查询")
        self.setGeometry(100, 100, 900, 600)
        self.init_ui()
        self.load_orders()

    def init_ui(self):
        layout = QVBoxLayout(self)
        title_label = QLabel("📋 当日交易订单查询")
        title_label.setStyleSheet("font-size: 16px; font-weight: bold; margin: 10px;")
        layout.addWidget(title_label)

        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "订单编号", "代码", "名称", "方向", "数量", "价格", "状态", "时间"
        ])
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)

        button_layout = QHBoxLayout()
        refresh_button = QPushButton("刷新")
        refresh_button.clicked.connect(self.load_orders)
        button_layout.addWidget(refresh_button)
        cancel_button = QPushButton("取消订单")
        cancel_button.clicked.connect(self.cancel_selected_order)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)

    def load_orders(self):
        """加载订单数据"""
        try:
            orders = self.myquant_client.get_orders() if self.myquant_client.is_connected() else []
            self.table.setRowCount(len(orders))
            for row, order in enumerate(orders):
                self.table.setItem(row, 0, QTableWidgetItem(order.get("order_id", "")))
                self.table.setItem(row, 1, QTableWidgetItem(order.get("symbol", "")))
                self.table.setItem(row, 2, QTableWidgetItem(self.myquant_client.get_stock_name(order.get("symbol", ""))))
                self.table.setItem(row, 3, QTableWidgetItem(order.get("side", "")))
                self.table.setItem(row, 4, QTableWidgetItem(str(order.get("volume", 0))))
                self.table.setItem(row, 5, QTableWidgetItem(str(order.get("price", 0.0))))
                self.table.setItem(row, 6, QTableWidgetItem(order.get("status", "")))
                self.table.setItem(row, 7, QTableWidgetItem(order.get("time", "")))
        except Exception as e:
            logging.error(f"加载订单失败: {e}")
            QMessageBox.critical(self, "错误", f"加载订单失败: {e}")

    def cancel_selected_order(self):
        """取消选中的订单"""
        try:
            selected = self.table.currentRow()
            if selected < 0:
                QMessageBox.warning(self, "警告", "请选择一个订单")
                return
            order_id = self.table.item(selected, 0).text()
            if self.myquant_client.order_cancel(order_id):
                self.load_orders()
                self.parent().logger.log(f"取消订单成功: {order_id}", "SUCCESS")
            else:
                self.parent().logger.log("取消订单失败", "ERROR")
                QMessageBox.critical(self, "错误", "取消订单失败")
        except Exception as e:
            self.parent().logger.log(f"取消订单异常: {e}", "ERROR")
            QMessageBox.critical(self, "错误", f"取消订单失败: {e}")

class SimpleHistoricalDataDialog(QDialog):
    """历史数据下载对话框"""

    def __init__(self, myquant_client: MyQuantClient, parent=None):
        super().__init__(parent)
        self.myquant_client = myquant_client
        self.setWindowTitle("下载历史数据")
        self.setGeometry(200, 200, 400, 300)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        self.symbol_input = QLineEdit()
        self.symbol_input.setPlaceholderText("请输入股票代码")
        layout.addWidget(self.symbol_input)

        self.period_combo = QComboBox()
        self.period_combo.addItems(["1m", "5m", "15m", "30m", "1h", "1d"])
        layout.addWidget(self.period_combo)

        self.start_date_input = QLineEdit()
        self.start_date_input.setPlaceholderText("开始日期 (YYYY-MM-DD)")
        layout.addWidget(self.start_date_input)

        self.end_date_input = QLineEdit()
        self.end_date_input.setPlaceholderText("结束日期 (YYYY-MM-DD)")
        layout.addWidget(self.end_date_input)

        download_button = QPushButton("下载")
        download_button.clicked.connect(self.download_data)
        layout.addWidget(download_button)

    def download_data(self):
        """下载历史数据"""
        try:
            symbol = self.symbol_input.text().strip()
            period = self.period_combo.currentText()
            start_date = self.start_date_input.text().strip()
            end_date = self.end_date_input.text().strip()
            if not all([symbol, start_date, end_date]):
                QMessageBox.warning(self, "警告", "请填写所有字段")
                return
            data = self.myquant_client.history(symbol, period, start_date, end_date)
            if data:
                df = pd.DataFrame(data)
                filename = f"{symbol}_{period}_{start_date}_{end_date}.csv"
                df.to_csv(filename, index=False)
                self.parent().logger.log(f"历史数据下载成功: {filename}", "SUCCESS")
                QMessageBox.information(self, "成功", "数据已保存为 CSV 文件")
            else:
                self.parent().logger.log(f"历史数据下载失败: 无数据", "ERROR")
                QMessageBox.critical(self, "错误", "无数据返回")
        except Exception as e:
            self.parent().logger.log(f"下载历史数据异常: {e}", "ERROR")
            QMessageBox.critical(self, "错误", f"下载失败: {e}")

class SettingsDialog(QDialog):
    """设置对话框"""

    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("设置")
        self.setGeometry(200, 200, 400, 300)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        self.token_input = QLineEdit()
        self.token_input.setPlaceholderText("请输入 MyQuant Token")
        self.token_input.setText(self.config.get("myquant.token", ""))
        layout.addWidget(self.token_input)

        self.account_id_input = QLineEdit()
        self.account_id_input.setPlaceholderText("请输入账户 ID")
        self.account_id_input.setText(self.config.get("myquant.account_id", ""))
        layout.addWidget(self.account_id_input)

        self.simulation_mode = QComboBox()
        self.simulation_mode.addItems(["模拟交易", "真实交易"])
        self.simulation_mode.setCurrentText("模拟交易" if self.config.get("trading.simulation_mode") else "真实交易")
        layout.addWidget(self.simulation_mode)

        save_button = QPushButton("保存")
        save_button.clicked.connect(self.save_settings)
        layout.addWidget(save_button)

    def save_settings(self):
        """保存设置"""
        try:
            self.config.set("myquant.token", self.token_input.text().strip())
            self.config.set("myquant.account_id", self.account_id_input.text().strip())
            self.config.set("trading.simulation_mode", self.simulation_mode.currentText() == "模拟交易")
            if self.config.save_config():
                self.parent().logger.log("设置保存成功", "SUCCESS")
                QMessageBox.information(self, "成功", "设置已保存")
            else:
                self.parent().logger.log("设置保存失败", "ERROR")
                QMessageBox.critical(self, "错误", "设置保存失败")
        except Exception as e:
            self.parent().logger.log(f"保存设置异常: {e}", "ERROR")
            QMessageBox.critical(self, "错误", f"保存失败: {e}")