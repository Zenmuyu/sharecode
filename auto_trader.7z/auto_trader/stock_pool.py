from typing import Dict, List
from .myquant_client import MyQuantClient

class StockPool:
    """股票池管理，维护关注股票和持仓"""

    def __init__(self, myquant_client: MyQuantClient):
        self.myquant_client = myquant_client
        self.stocks = {}
        self.watchlist = []

    def add_stock(self, code: str) -> None:
        """添加股票到关注列表"""
        if code not in self.stocks:
            self.stocks[code] = {"code": code, "name": self.myquant_client.get_stock_name(code)}
            self.watchlist.append(code)

    def add_position_stocks(self, positions: List[Dict]) -> None:
        """添加持仓股票"""
        for pos in positions:
            code = pos["代码"]
            self.stocks[code] = pos
            if code not in self.watchlist:
                self.watchlist.append(code)

    def get_all_stocks(self) -> Dict:
        return self.stocks

    def remove_stock(self, code: str) -> None:
        """从关注列表移除股票"""
        if code in self.stocks:
            del self.stocks[code]
        if code in self.watchlist:
            self.watchlist.remove(code)