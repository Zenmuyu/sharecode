from PyQt5.QtCore import QThread, pyqtSignal
from .myquant_client import MyQuantClient
from .stock_pool import StockPool
from .utils import execute_with_timeout
import logging
import threading

class InitializationThread(QThread):
    """系统初始化线程"""
    initialization_progress = pyqtSignal(int, str)
    log_message = pyqtSignal(str, str)
    account_updated = pyqtSignal(dict)
    status_message = pyqtSignal(str)

    def __init__(self, myquant_client: MyQuantClient, stock_pool: StockPool):
        super().__init__()
        self.myquant_client = myquant_client
        self.stock_pool = stock_pool
        self._stop_requested = False
        self.initialization_completed = False
        self._lock = threading.Lock()

    def run(self):
        """执行初始化"""
        try:
            self.log_message.emit("开始初始化...", "INFO")
            self.initialization_progress.emit(10, "连接 MyQuant...")
            success, _ = execute_with_timeout(self.myquant_client.connect, 10, "连接 MyQuant", "[初始化]")
            if not success:
                self.log_message.emit("MyQuant 连接失败", "ERROR")
                self.status_message.emit("连接失败")
                return

            self.initialization_progress.emit(50, "获取持仓...")
            with self._lock:
                positions = self.myquant_client.get_positions()
                self.stock_pool.add_position_stocks(positions)
                self.account_updated.emit(self.myquant_client.get_account_info())

            self.initialization_progress.emit(100, "初始化完成")
            self.log_message.emit("系统初始化完成", "SUCCESS")
            self.initialization_completed = True
        except Exception as e:
            self.log_message.emit(f"初始化异常: {e}", "ERROR")
            self.status_message.emit("初始化失败")

    def stop(self):
        """停止初始化"""
        self._stop_requested = True

class SimpleDownloadThread(QThread):
    """历史数据下载线程"""
    progress = pyqtSignal(int)
    log_message = pyqtSignal(str, str)
    completed = pyqtSignal(str)

    def __init__(self, myquant_client: MyQuantClient, symbol: str, period: str, start_date: str, end_date: str):
        super().__init__()
        self.myquant_client = myquant_client
        self.symbol = symbol
        self.period = period
        self.start_date = start_date
        self.end_date = end_date

    def run(self):
        """执行下载"""
        try:
            self.log_message.emit(f"开始下载 {self.symbol} 的历史数据...", "INFO")
            self.progress.emit(10)
            data = self.myquant_client.history(self.symbol, self.period, self.start_date, self.end_date)
            self.progress.emit(50)
            if data:
                df = pd.DataFrame(data)
                filename = f"{self.symbol}_{self.period}_{self.start_date}_{self.end_date}.csv"
                df.to_csv(filename, index=False)
                self.progress.emit(100)
                self.log_message.emit(f"历史数据下载成功: {filename}", "SUCCESS")
                self.completed.emit(filename)
            else:
                self.log_message.emit("无历史数据返回", "ERROR")
        except Exception as e:
            self.log_message.emit(f"下载历史数据异常: {e}", "ERROR")