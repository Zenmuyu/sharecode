import logging
from datetime import datetime
from PyQt5.QtWidgets import QTextEdit

class Logger:
    """日志管理类，支持文件和 UI 输出"""

    def __init__(self, text_widget: QTextEdit):
        self.text_widget = text_widget
        self.setup_logging()

    def setup_logging(self) -> None:
        """配置日志系统，输出到 auto_trader.log"""
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
            handlers=[logging.FileHandler("auto_trader.log", encoding="utf-8")],
        )

    def log(self, message: str, level: str = "INFO") -> None:
        """添加日志消息到 UI 和文件"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        color_map = {"INFO": "black", "WARNING": "orange", "ERROR": "red", "SUCCESS": "green"}
        color = color_map.get(level, "black")
        formatted_msg = f'<span style="color: {color}">[{timestamp}] {message}</span>'
        self.text_widget.append(formatted_msg)
        getattr(logging, level.lower(), logging.info)(message)