import logging
import threading
from datetime import datetime, timedelta
from typing import Dict, List

try:
    from myquant_api_loader import MyQuantAPILoader
    loader = MyQuantAPILoader()
    gm = loader.get_gm_module()
    MYQUANT_AVAILABLE = loader.is_available()
except ImportError:
    try:
        import gm as _gm_pkg
        gm = getattr(_gm_pkg, "api", _gm_pkg)
        MYQUANT_AVAILABLE = True
    except Exception:
        class _GmStub:
            ADJUST_PREV = None
            OrderSide_Buy = "BUY"
            OrderSide_Sell = "SELL"
            PositionEffect_Open = "OPEN"
            PositionEffect_Close = "CLOSE"
            OrderType_Market = "MARKET"
            OrderType_Limit = "LIMIT"
            def set_token(self, token): pass
            def set_account_id(self, account_id): pass
            def current(self, symbols): return []
            def get_cash(self): return {}
            def get_position(self): return []
            def history(self, *args, **kwargs): return []
            def order_volume(self, *args, **kwargs): return []
            def order_cancel(self, *args, **kwargs): return []
            def get_orders(self): return []
            def get_unfinished_orders(self): return []
        gm = _GmStub()
        MYQUANT_AVAILABLE = False

try:
    import akshare as ak
    AKSHARE_AVAILABLE = True
except ImportError:
    ak = None
    AKSHARE_AVAILABLE = False

from .config import Config
from .utils import execute_with_timeout

class MyQuantClient:
    """掘金量化客户端接口"""

    def __init__(self, config: Config):
        self.config = config
        self.connected = False
        self.account_id = None
        self.token = None
        self.data_cache = {}
        self.cache_time = {}
        self.cache_expiry = 5
        self._lock = threading.Lock()

    def connect(self) -> bool:
        """连接到掘金客户端"""
        if not MYQUANT_AVAILABLE:
            logging.error("MyQuant API不可用")
            return False
        try:
            self.token = self.config.get("myquant.token") or "85db8b06e888f0e16b7041da679079ecd529e117"
            self.account_id = self.config.get("myquant.account_id") or "41702793-80bf-11f0-8b8b-00163e022aa6"
            gm.set_token(self.token)
            gm.set_account_id(self.account_id)
            success, data = execute_with_timeout(lambda: gm.current(["SZSE.000001"]), 5, "连接 MyQuant", "[MyQuant]")
            if success and data:
                with self._lock:
                    self.connected = True
                logging.info("✅ MyQuant客户端连接成功")
                return True
            logging.warning("连接测试失败")
            self.connected = False
            return False
        except Exception as e:
            logging.error(f"连接MyQuant失败: {e}")
            self.connected = False
            return False

    def is_connected(self) -> bool:
        return self.connected and MYQUANT_AVAILABLE

    def get_positions(self) -> List[Dict]:
        """获取持仓信息"""
        if not self.is_connected():
            return []
        try:
            success, positions = execute_with_timeout(gm.get_position, 5, "获取持仓", "[MyQuant]")
            if not success or not positions:
                return []
            result = []
            for pos in positions:
                try:
                    symbol = pos.get('symbol', pos.get('code', ''))
                    volume = pos.get('volume', pos.get('position', 0))
                    vwap = pos.get('vwap', pos.get('avg_price', 0))
                    price = pos.get('price', pos.get('last_price', 0))
                    market_value = pos.get('market_value', 0)
                    pnl = pos.get('pnl', 0)
                    if volume > 0 and symbol:
                        clean_code = symbol.replace("SHSE.", "").replace("SZSE.", "")
                        result.append({
                            "代码": clean_code,
                            "名称": self.get_stock_name(clean_code),
                            "数量": volume,
                            "成本价": vwap,
                            "现价": price,
                            "市值": market_value,
                            "盈亏": pnl,
                        })
                except Exception as e:
                    logging.warning(f"处理单条持仓数据异常: {e}")
            return result
        except Exception as e:
            logging.error(f"[执行引擎] 获取持仓异常: {e}")
            return []

    def get_stock_name(self, symbol: str) -> str:
        """获取股票名称"""
        if not AKSHARE_AVAILABLE:
            return symbol
        try:
            df = ak.stock_individual_info_em(symbol=symbol.replace("SHSE.", "").replace("SZSE.", ""))
            return df.get("stock_name", symbol)
        except Exception as e:
            logging.warning(f"获取股票名称失败: {e}")
            return symbol

    def get_account_info(self) -> Dict:
        """获取账户信息"""
        if not self.is_connected():
            return {}
        try:
            success, cash = execute_with_timeout(gm.get_cash, 5, "获取账户信息", "[MyQuant]")
            if success:
                return {
                    "total_assets": cash.get("total_assets", 0.0),
                    "available_cash": cash.get("available_cash", 0.0),
                    "market_value": cash.get("market_value", 0.0),
                    "daily_pnl": cash.get("pnl", 0.0),
                }
            return {}
        except Exception as e:
            logging.error(f"获取账户信息失败: {e}")
            return {}

    def order_volume(self, symbol: str, volume: int, side: str, order_type: str, price: float = 0.0) -> str:
        """下单"""
        if not self.is_connected():
            return ""
        try:
            order_id = gm.order_volume(
                symbol=symbol,
                volume=volume,
                side=side,
                order_type=order_type,
                position_effect=self.PositionEffect_Open,
                price=price
            )
            return order_id
        except Exception as e:
            logging.error(f"下单失败: {e}")
            return ""

    def order_cancel(self, order_id: str) -> bool:
        """取消订单"""
        if not self.is_connected():
            return False
        try:
            gm.order_cancel(order_id)
            return True
        except Exception as e:
            logging.error(f"取消订单失败: {e}")
            return False

    def get_orders(self) -> List[Dict]:
        """获取订单列表"""
        if not self.is_connected():
            return []
        try:
            success, orders = execute_with_timeout(gm.get_orders, 5, "获取订单", "[MyQuant]")
            if not success or not orders:
                return []
            result = []
            for order in orders:
                result.append({
                    "order_id": order.get("order_id", ""),
                    "symbol": order.get("symbol", ""),
                    "name": self.get_stock_name(order.get("symbol", "")),
                    "side": order.get("side", ""),
                    "volume": order.get("volume", 0),
                    "price": order.get("price", 0.0),
                    "status": order.get("status", ""),
                    "time": order.get("time", "")
                })
            return result
        except Exception as e:
            logging.error(f"获取订单失败: {e}")
            return []

    def history(self, symbol: str, period: str, start_date: str, end_date: str) -> List[Dict]:
        """获取历史数据"""
        if not self.is_connected():
            return []
        try:
            success, data = execute_with_timeout(
                lambda: gm.history(symbol, period, start_date, end_date, adjust=self.ADJUST_PREV),
                10, f"获取 {symbol} 历史数据", "[MyQuant]"
            )
            if success:
                return data
            return []
        except Exception as e:
            logging.error(f"获取历史数据失败: {e}")
            return []