from PyQt5.QtWidgets import QMainWindow, QStatusBar, QSplitter, QTabWidget, QTextEdit, QVBoxLayout, QWidget
from PyQt5.QtCore import Qt
from .config import Config
from .logger import Logger
from .myquant_client import MyQuantClient
from .stock_pool import StockPool
from .execution_engine import ExecutionEngine, SimExecutionEngine, RealExecutionEngine
from .ui_components import ChartWidget, TradePanel
from .dialogs import OrdersDialog, SimpleHistoricalDataDialog, SettingsDialog
from .threads import InitializationThread
import logging

class MainWindow(QMainWindow):
    """主窗口"""

    def __init__(self):
        super().__init__()
        self.config = Config()
        self.log_text = QTextEdit()
        self.logger = Logger(self.log_text)
        self.myquant_client = MyQuantClient(self.config)
        self.stock_pool = StockPool(self.myquant_client)
        self.execution_engine = SimExecutionEngine(self) if self.config.get("trading.simulation_mode") else RealExecutionEngine(self)
        self.init_ui()
        self.init_thread = InitializationThread(self.myquant_client, self.stock_pool)
        self.init_thread.log_message.connect(self.logger.log)
        self.init_thread.status_message.connect(self.statusBar().showMessage)
        self.init_thread.account_updated.connect(self.update_account_info)
        self.init_thread.initialization_progress.connect(self.update_progress)
        self.init_thread.start()

    def init_ui(self):
        """初始化 UI"""
        self.setWindowTitle("A股自动交易系统")
        self.setGeometry(100, 100, 1200, 800)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        splitter = QSplitter(Qt.Horizontal)
        self.chart_widget = ChartWidget()
        splitter.addWidget(self.chart_widget)

        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        self.trade_panel = TradePanel(self)
        right_layout.addWidget(self.trade_panel)
        self.log_text.setReadOnly(True)
        right_layout.addWidget(self.log_text)
        splitter.addWidget(right_panel)
        layout.addWidget(splitter)

        self.statusBar().showMessage("初始化中...")

        self.create_menu()

    def create_menu(self):
        """创建菜单栏"""
        menubar = self.menuBar()
        file_menu = menubar.addMenu("文件")
        settings_action = file_menu.addAction("设置")
        settings_action.triggered.connect(self.open_settings_dialog)
        orders_action = file_menu.addAction("订单查询")
        orders_action.triggered.connect(self.open_orders_dialog)
        data_action = file_menu.addAction("下载历史数据")
        data_action.triggered.connect(self.open_data_dialog)

    def open_settings_dialog(self):
        """打开设置对话框"""
        dialog = SettingsDialog(self.config, self)
        dialog.exec_()

    def open_orders_dialog(self):
        """打开订单查询对话框"""
        dialog = OrdersDialog(self.myquant_client, self.config, self)
        dialog.exec_()

    def open_data_dialog(self):
        """打开历史数据下载对话框"""
        dialog = SimpleHistoricalDataDialog(self.myquant_client, self)
        dialog.exec_()

    def update_account_info(self, account_info: dict):
        """更新账户信息"""
        self.logger.log(f"账户更新: 总资产 {account_info.get('total_assets', 0)}", "INFO")

    def update_progress(self, progress: int, message: str):
        """更新初始化进度"""
        self.statusBar().showMessage(f"{message} ({progress}%)")